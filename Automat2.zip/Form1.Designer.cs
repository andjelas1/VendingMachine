﻿namespace VendingMachine
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.novcanica5 = new System.Windows.Forms.Button();
            this.novcanica10 = new System.Windows.Forms.Button();
            this.novcanica20 = new System.Windows.Forms.Button();
            this.novcanica50 = new System.Windows.Forms.Button();
            this.novcanica100 = new System.Windows.Forms.Button();
            this.novcanica200 = new System.Windows.Forms.Button();
            this.panelMagacin = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.s66 = new System.Windows.Forms.TextBox();
            this.p61 = new System.Windows.Forms.Button();
            this.s65 = new System.Windows.Forms.TextBox();
            this.p63 = new System.Windows.Forms.Button();
            this.p66 = new System.Windows.Forms.Button();
            this.p62 = new System.Windows.Forms.Button();
            this.s64 = new System.Windows.Forms.TextBox();
            this.s61 = new System.Windows.Forms.TextBox();
            this.p65 = new System.Windows.Forms.Button();
            this.p64 = new System.Windows.Forms.Button();
            this.s63 = new System.Windows.Forms.TextBox();
            this.s62 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.s56 = new System.Windows.Forms.TextBox();
            this.p51 = new System.Windows.Forms.Button();
            this.s55 = new System.Windows.Forms.TextBox();
            this.p53 = new System.Windows.Forms.Button();
            this.p56 = new System.Windows.Forms.Button();
            this.p52 = new System.Windows.Forms.Button();
            this.s54 = new System.Windows.Forms.TextBox();
            this.s51 = new System.Windows.Forms.TextBox();
            this.p55 = new System.Windows.Forms.Button();
            this.p54 = new System.Windows.Forms.Button();
            this.s53 = new System.Windows.Forms.TextBox();
            this.s52 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.s46 = new System.Windows.Forms.TextBox();
            this.p41 = new System.Windows.Forms.Button();
            this.s45 = new System.Windows.Forms.TextBox();
            this.p43 = new System.Windows.Forms.Button();
            this.p46 = new System.Windows.Forms.Button();
            this.p42 = new System.Windows.Forms.Button();
            this.s44 = new System.Windows.Forms.TextBox();
            this.s41 = new System.Windows.Forms.TextBox();
            this.p45 = new System.Windows.Forms.Button();
            this.p44 = new System.Windows.Forms.Button();
            this.s43 = new System.Windows.Forms.TextBox();
            this.s42 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.s36 = new System.Windows.Forms.TextBox();
            this.p31 = new System.Windows.Forms.Button();
            this.s35 = new System.Windows.Forms.TextBox();
            this.p33 = new System.Windows.Forms.Button();
            this.p36 = new System.Windows.Forms.Button();
            this.p32 = new System.Windows.Forms.Button();
            this.s34 = new System.Windows.Forms.TextBox();
            this.s31 = new System.Windows.Forms.TextBox();
            this.p35 = new System.Windows.Forms.Button();
            this.p34 = new System.Windows.Forms.Button();
            this.s33 = new System.Windows.Forms.TextBox();
            this.s32 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.s26 = new System.Windows.Forms.TextBox();
            this.s25 = new System.Windows.Forms.TextBox();
            this.p26 = new System.Windows.Forms.Button();
            this.s24 = new System.Windows.Forms.TextBox();
            this.p25 = new System.Windows.Forms.Button();
            this.s23 = new System.Windows.Forms.TextBox();
            this.p21 = new System.Windows.Forms.Button();
            this.s22 = new System.Windows.Forms.TextBox();
            this.p24 = new System.Windows.Forms.Button();
            this.s21 = new System.Windows.Forms.TextBox();
            this.p22 = new System.Windows.Forms.Button();
            this.p23 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.s16 = new System.Windows.Forms.TextBox();
            this.s15 = new System.Windows.Forms.TextBox();
            this.s14 = new System.Windows.Forms.TextBox();
            this.s13 = new System.Windows.Forms.TextBox();
            this.s12 = new System.Windows.Forms.TextBox();
            this.s11 = new System.Windows.Forms.TextBox();
            this.p16 = new System.Windows.Forms.Button();
            this.p15 = new System.Windows.Forms.Button();
            this.p14 = new System.Windows.Forms.Button();
            this.p13 = new System.Windows.Forms.Button();
            this.p12 = new System.Windows.Forms.Button();
            this.p11 = new System.Windows.Forms.Button();
            this.panelOdrzavanje = new System.Windows.Forms.Panel();
            this.ispraznikasu = new System.Windows.Forms.Button();
            this.ubaciNovcanicu = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ubacenaNovcanica = new System.Windows.Forms.TextBox();
            this.napuniAutomat = new System.Windows.Forms.Button();
            this.ubaciArtikal = new System.Windows.Forms.Button();
            this.procenatPopusta = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.popustNaDan = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.rok = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cena = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.naziv = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.kolicina = new System.Windows.Forms.TextBox();
            this.infoPozicije = new System.Windows.Forms.Label();
            this.kljuc = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.kredit = new System.Windows.Forms.TextBox();
            this.kusur = new System.Windows.Forms.RichTextBox();
            this.isporuceno = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.vratiKusur = new System.Windows.Forms.Button();
            this.novcanica2 = new System.Windows.Forms.Button();
            this.novcanica1 = new System.Windows.Forms.Button();
            this.stanjeKase = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.preuzmiKusur = new System.Windows.Forms.Button();
            this.panelMagacin.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelOdrzavanje.SuspendLayout();
            this.SuspendLayout();
            // 
            // novcanica5
            // 
            this.novcanica5.Location = new System.Drawing.Point(493, 85);
            this.novcanica5.Margin = new System.Windows.Forms.Padding(2);
            this.novcanica5.Name = "novcanica5";
            this.novcanica5.Size = new System.Drawing.Size(87, 27);
            this.novcanica5.TabIndex = 0;
            this.novcanica5.Text = "5";
            this.novcanica5.UseVisualStyleBackColor = true;
            this.novcanica5.Click += new System.EventHandler(this.novcanica_Click);
            // 
            // novcanica10
            // 
            this.novcanica10.Location = new System.Drawing.Point(596, 85);
            this.novcanica10.Margin = new System.Windows.Forms.Padding(2);
            this.novcanica10.Name = "novcanica10";
            this.novcanica10.Size = new System.Drawing.Size(87, 27);
            this.novcanica10.TabIndex = 1;
            this.novcanica10.Text = "10";
            this.novcanica10.UseVisualStyleBackColor = true;
            this.novcanica10.Click += new System.EventHandler(this.novcanica_Click);
            // 
            // novcanica20
            // 
            this.novcanica20.Location = new System.Drawing.Point(493, 129);
            this.novcanica20.Margin = new System.Windows.Forms.Padding(2);
            this.novcanica20.Name = "novcanica20";
            this.novcanica20.Size = new System.Drawing.Size(87, 27);
            this.novcanica20.TabIndex = 2;
            this.novcanica20.Text = "20";
            this.novcanica20.UseVisualStyleBackColor = true;
            this.novcanica20.Click += new System.EventHandler(this.novcanica_Click);
            // 
            // novcanica50
            // 
            this.novcanica50.Location = new System.Drawing.Point(596, 129);
            this.novcanica50.Margin = new System.Windows.Forms.Padding(2);
            this.novcanica50.Name = "novcanica50";
            this.novcanica50.Size = new System.Drawing.Size(87, 27);
            this.novcanica50.TabIndex = 3;
            this.novcanica50.Text = "50";
            this.novcanica50.UseVisualStyleBackColor = true;
            this.novcanica50.Click += new System.EventHandler(this.novcanica_Click);
            // 
            // novcanica100
            // 
            this.novcanica100.Location = new System.Drawing.Point(493, 169);
            this.novcanica100.Margin = new System.Windows.Forms.Padding(2);
            this.novcanica100.Name = "novcanica100";
            this.novcanica100.Size = new System.Drawing.Size(87, 27);
            this.novcanica100.TabIndex = 4;
            this.novcanica100.Text = "100";
            this.novcanica100.UseVisualStyleBackColor = true;
            this.novcanica100.Click += new System.EventHandler(this.novcanica_Click);
            // 
            // novcanica200
            // 
            this.novcanica200.Location = new System.Drawing.Point(596, 169);
            this.novcanica200.Margin = new System.Windows.Forms.Padding(2);
            this.novcanica200.Name = "novcanica200";
            this.novcanica200.Size = new System.Drawing.Size(87, 27);
            this.novcanica200.TabIndex = 5;
            this.novcanica200.Text = "200";
            this.novcanica200.UseVisualStyleBackColor = true;
            this.novcanica200.Click += new System.EventHandler(this.novcanica_Click);
            // 
            // panelMagacin
            // 
            this.panelMagacin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelMagacin.Controls.Add(this.panel6);
            this.panelMagacin.Controls.Add(this.panel5);
            this.panelMagacin.Controls.Add(this.panel4);
            this.panelMagacin.Controls.Add(this.panel3);
            this.panelMagacin.Controls.Add(this.panel2);
            this.panelMagacin.Controls.Add(this.panel1);
            this.panelMagacin.Location = new System.Drawing.Point(25, 23);
            this.panelMagacin.Margin = new System.Windows.Forms.Padding(2);
            this.panelMagacin.Name = "panelMagacin";
            this.panelMagacin.Size = new System.Drawing.Size(456, 702);
            this.panelMagacin.TabIndex = 6;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.s66);
            this.panel6.Controls.Add(this.p61);
            this.panel6.Controls.Add(this.s65);
            this.panel6.Controls.Add(this.p63);
            this.panel6.Controls.Add(this.p66);
            this.panel6.Controls.Add(this.p62);
            this.panel6.Controls.Add(this.s64);
            this.panel6.Controls.Add(this.s61);
            this.panel6.Controls.Add(this.p65);
            this.panel6.Controls.Add(this.p64);
            this.panel6.Controls.Add(this.s63);
            this.panel6.Controls.Add(this.s62);
            this.panel6.Location = new System.Drawing.Point(9, 585);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(437, 98);
            this.panel6.TabIndex = 1;
            // 
            // s66
            // 
            this.s66.Enabled = false;
            this.s66.Location = new System.Drawing.Point(363, 61);
            this.s66.Margin = new System.Windows.Forms.Padding(2);
            this.s66.Name = "s66";
            this.s66.Size = new System.Drawing.Size(45, 27);
            this.s66.TabIndex = 65;
            this.s66.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s66.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p61
            // 
            this.p61.Location = new System.Drawing.Point(11, 2);
            this.p61.Margin = new System.Windows.Forms.Padding(2);
            this.p61.Name = "p61";
            this.p61.Size = new System.Drawing.Size(62, 55);
            this.p61.TabIndex = 54;
            this.p61.Text = "button27";
            this.p61.UseVisualStyleBackColor = true;
            this.p61.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s65
            // 
            this.s65.Enabled = false;
            this.s65.Location = new System.Drawing.Point(288, 61);
            this.s65.Margin = new System.Windows.Forms.Padding(2);
            this.s65.Name = "s65";
            this.s65.Size = new System.Drawing.Size(45, 27);
            this.s65.TabIndex = 64;
            this.s65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s65.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p63
            // 
            this.p63.Location = new System.Drawing.Point(149, 2);
            this.p63.Margin = new System.Windows.Forms.Padding(2);
            this.p63.Name = "p63";
            this.p63.Size = new System.Drawing.Size(62, 55);
            this.p63.TabIndex = 56;
            this.p63.Text = "button30";
            this.p63.UseVisualStyleBackColor = true;
            this.p63.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p66
            // 
            this.p66.Location = new System.Drawing.Point(354, 2);
            this.p66.Margin = new System.Windows.Forms.Padding(2);
            this.p66.Name = "p66";
            this.p66.Size = new System.Drawing.Size(62, 55);
            this.p66.TabIndex = 59;
            this.p66.Text = "button25";
            this.p66.UseVisualStyleBackColor = true;
            this.p66.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p62
            // 
            this.p62.Location = new System.Drawing.Point(83, 2);
            this.p62.Margin = new System.Windows.Forms.Padding(2);
            this.p62.Name = "p62";
            this.p62.Size = new System.Drawing.Size(62, 55);
            this.p62.TabIndex = 55;
            this.p62.Text = "button29";
            this.p62.UseVisualStyleBackColor = true;
            this.p62.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s64
            // 
            this.s64.Enabled = false;
            this.s64.Location = new System.Drawing.Point(223, 61);
            this.s64.Margin = new System.Windows.Forms.Padding(2);
            this.s64.Name = "s64";
            this.s64.Size = new System.Drawing.Size(45, 27);
            this.s64.TabIndex = 63;
            this.s64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s64.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s61
            // 
            this.s61.Enabled = false;
            this.s61.Location = new System.Drawing.Point(19, 61);
            this.s61.Margin = new System.Windows.Forms.Padding(2);
            this.s61.Name = "s61";
            this.s61.Size = new System.Drawing.Size(45, 27);
            this.s61.TabIndex = 60;
            this.s61.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s61.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p65
            // 
            this.p65.Location = new System.Drawing.Point(281, 2);
            this.p65.Margin = new System.Windows.Forms.Padding(2);
            this.p65.Name = "p65";
            this.p65.Size = new System.Drawing.Size(62, 55);
            this.p65.TabIndex = 58;
            this.p65.Text = "button26";
            this.p65.UseVisualStyleBackColor = true;
            this.p65.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p64
            // 
            this.p64.Location = new System.Drawing.Point(215, 2);
            this.p64.Margin = new System.Windows.Forms.Padding(2);
            this.p64.Name = "p64";
            this.p64.Size = new System.Drawing.Size(62, 55);
            this.p64.TabIndex = 57;
            this.p64.Text = "button28";
            this.p64.UseVisualStyleBackColor = true;
            this.p64.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s63
            // 
            this.s63.Enabled = false;
            this.s63.Location = new System.Drawing.Point(160, 61);
            this.s63.Margin = new System.Windows.Forms.Padding(2);
            this.s63.Name = "s63";
            this.s63.Size = new System.Drawing.Size(45, 27);
            this.s63.TabIndex = 62;
            this.s63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s63.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s62
            // 
            this.s62.Enabled = false;
            this.s62.Location = new System.Drawing.Point(95, 61);
            this.s62.Margin = new System.Windows.Forms.Padding(2);
            this.s62.Name = "s62";
            this.s62.Size = new System.Drawing.Size(45, 27);
            this.s62.TabIndex = 61;
            this.s62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s62.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.s56);
            this.panel5.Controls.Add(this.p51);
            this.panel5.Controls.Add(this.s55);
            this.panel5.Controls.Add(this.p53);
            this.panel5.Controls.Add(this.p56);
            this.panel5.Controls.Add(this.p52);
            this.panel5.Controls.Add(this.s54);
            this.panel5.Controls.Add(this.s51);
            this.panel5.Controls.Add(this.p55);
            this.panel5.Controls.Add(this.p54);
            this.panel5.Controls.Add(this.s53);
            this.panel5.Controls.Add(this.s52);
            this.panel5.Location = new System.Drawing.Point(9, 470);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(437, 98);
            this.panel5.TabIndex = 1;
            // 
            // s56
            // 
            this.s56.Enabled = false;
            this.s56.Location = new System.Drawing.Point(363, 61);
            this.s56.Margin = new System.Windows.Forms.Padding(2);
            this.s56.Name = "s56";
            this.s56.Size = new System.Drawing.Size(45, 27);
            this.s56.TabIndex = 53;
            this.s56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s56.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p51
            // 
            this.p51.Location = new System.Drawing.Point(11, 2);
            this.p51.Margin = new System.Windows.Forms.Padding(2);
            this.p51.Name = "p51";
            this.p51.Size = new System.Drawing.Size(62, 55);
            this.p51.TabIndex = 42;
            this.p51.Text = "button21";
            this.p51.UseVisualStyleBackColor = true;
            this.p51.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s55
            // 
            this.s55.Enabled = false;
            this.s55.Location = new System.Drawing.Point(288, 61);
            this.s55.Margin = new System.Windows.Forms.Padding(2);
            this.s55.Name = "s55";
            this.s55.Size = new System.Drawing.Size(45, 27);
            this.s55.TabIndex = 52;
            this.s55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s55.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p53
            // 
            this.p53.Location = new System.Drawing.Point(149, 2);
            this.p53.Margin = new System.Windows.Forms.Padding(2);
            this.p53.Name = "p53";
            this.p53.Size = new System.Drawing.Size(62, 55);
            this.p53.TabIndex = 44;
            this.p53.Text = "button24";
            this.p53.UseVisualStyleBackColor = true;
            this.p53.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p56
            // 
            this.p56.Location = new System.Drawing.Point(354, 2);
            this.p56.Margin = new System.Windows.Forms.Padding(2);
            this.p56.Name = "p56";
            this.p56.Size = new System.Drawing.Size(62, 55);
            this.p56.TabIndex = 47;
            this.p56.Text = "button19";
            this.p56.UseVisualStyleBackColor = true;
            this.p56.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p52
            // 
            this.p52.Location = new System.Drawing.Point(83, 2);
            this.p52.Margin = new System.Windows.Forms.Padding(2);
            this.p52.Name = "p52";
            this.p52.Size = new System.Drawing.Size(62, 55);
            this.p52.TabIndex = 43;
            this.p52.Text = "button23";
            this.p52.UseVisualStyleBackColor = true;
            this.p52.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s54
            // 
            this.s54.Enabled = false;
            this.s54.Location = new System.Drawing.Point(223, 61);
            this.s54.Margin = new System.Windows.Forms.Padding(2);
            this.s54.Name = "s54";
            this.s54.Size = new System.Drawing.Size(45, 27);
            this.s54.TabIndex = 51;
            this.s54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s54.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s51
            // 
            this.s51.Enabled = false;
            this.s51.Location = new System.Drawing.Point(19, 61);
            this.s51.Margin = new System.Windows.Forms.Padding(2);
            this.s51.Name = "s51";
            this.s51.Size = new System.Drawing.Size(45, 27);
            this.s51.TabIndex = 48;
            this.s51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s51.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p55
            // 
            this.p55.Location = new System.Drawing.Point(281, 2);
            this.p55.Margin = new System.Windows.Forms.Padding(2);
            this.p55.Name = "p55";
            this.p55.Size = new System.Drawing.Size(62, 55);
            this.p55.TabIndex = 46;
            this.p55.Text = "button20";
            this.p55.UseVisualStyleBackColor = true;
            this.p55.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p54
            // 
            this.p54.Location = new System.Drawing.Point(215, 2);
            this.p54.Margin = new System.Windows.Forms.Padding(2);
            this.p54.Name = "p54";
            this.p54.Size = new System.Drawing.Size(62, 55);
            this.p54.TabIndex = 45;
            this.p54.Text = "button22";
            this.p54.UseVisualStyleBackColor = true;
            this.p54.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s53
            // 
            this.s53.Enabled = false;
            this.s53.Location = new System.Drawing.Point(160, 61);
            this.s53.Margin = new System.Windows.Forms.Padding(2);
            this.s53.Name = "s53";
            this.s53.Size = new System.Drawing.Size(45, 27);
            this.s53.TabIndex = 50;
            this.s53.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s53.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s52
            // 
            this.s52.Enabled = false;
            this.s52.Location = new System.Drawing.Point(95, 61);
            this.s52.Margin = new System.Windows.Forms.Padding(2);
            this.s52.Name = "s52";
            this.s52.Size = new System.Drawing.Size(45, 27);
            this.s52.TabIndex = 49;
            this.s52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s52.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.s46);
            this.panel4.Controls.Add(this.p41);
            this.panel4.Controls.Add(this.s45);
            this.panel4.Controls.Add(this.p43);
            this.panel4.Controls.Add(this.p46);
            this.panel4.Controls.Add(this.p42);
            this.panel4.Controls.Add(this.s44);
            this.panel4.Controls.Add(this.s41);
            this.panel4.Controls.Add(this.p45);
            this.panel4.Controls.Add(this.p44);
            this.panel4.Controls.Add(this.s43);
            this.panel4.Controls.Add(this.s42);
            this.panel4.Location = new System.Drawing.Point(9, 355);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(437, 98);
            this.panel4.TabIndex = 1;
            // 
            // s46
            // 
            this.s46.Enabled = false;
            this.s46.Location = new System.Drawing.Point(363, 61);
            this.s46.Margin = new System.Windows.Forms.Padding(2);
            this.s46.Name = "s46";
            this.s46.Size = new System.Drawing.Size(45, 27);
            this.s46.TabIndex = 41;
            this.s46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s46.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p41
            // 
            this.p41.Location = new System.Drawing.Point(11, 2);
            this.p41.Margin = new System.Windows.Forms.Padding(2);
            this.p41.Name = "p41";
            this.p41.Size = new System.Drawing.Size(62, 55);
            this.p41.TabIndex = 30;
            this.p41.Text = "button15";
            this.p41.UseVisualStyleBackColor = true;
            this.p41.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s45
            // 
            this.s45.Enabled = false;
            this.s45.Location = new System.Drawing.Point(288, 61);
            this.s45.Margin = new System.Windows.Forms.Padding(2);
            this.s45.Name = "s45";
            this.s45.Size = new System.Drawing.Size(45, 27);
            this.s45.TabIndex = 40;
            this.s45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s45.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p43
            // 
            this.p43.Location = new System.Drawing.Point(149, 2);
            this.p43.Margin = new System.Windows.Forms.Padding(2);
            this.p43.Name = "p43";
            this.p43.Size = new System.Drawing.Size(62, 55);
            this.p43.TabIndex = 32;
            this.p43.Text = "button18";
            this.p43.UseVisualStyleBackColor = true;
            this.p43.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p46
            // 
            this.p46.Location = new System.Drawing.Point(354, 2);
            this.p46.Margin = new System.Windows.Forms.Padding(2);
            this.p46.Name = "p46";
            this.p46.Size = new System.Drawing.Size(62, 55);
            this.p46.TabIndex = 35;
            this.p46.Text = "button13";
            this.p46.UseVisualStyleBackColor = true;
            this.p46.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p42
            // 
            this.p42.Location = new System.Drawing.Point(83, 2);
            this.p42.Margin = new System.Windows.Forms.Padding(2);
            this.p42.Name = "p42";
            this.p42.Size = new System.Drawing.Size(62, 55);
            this.p42.TabIndex = 31;
            this.p42.Text = "button17";
            this.p42.UseVisualStyleBackColor = true;
            this.p42.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s44
            // 
            this.s44.Enabled = false;
            this.s44.Location = new System.Drawing.Point(223, 61);
            this.s44.Margin = new System.Windows.Forms.Padding(2);
            this.s44.Name = "s44";
            this.s44.Size = new System.Drawing.Size(45, 27);
            this.s44.TabIndex = 39;
            this.s44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s44.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s41
            // 
            this.s41.Enabled = false;
            this.s41.Location = new System.Drawing.Point(19, 61);
            this.s41.Margin = new System.Windows.Forms.Padding(2);
            this.s41.Name = "s41";
            this.s41.Size = new System.Drawing.Size(45, 27);
            this.s41.TabIndex = 36;
            this.s41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s41.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p45
            // 
            this.p45.Location = new System.Drawing.Point(281, 2);
            this.p45.Margin = new System.Windows.Forms.Padding(2);
            this.p45.Name = "p45";
            this.p45.Size = new System.Drawing.Size(62, 55);
            this.p45.TabIndex = 34;
            this.p45.Text = "button14";
            this.p45.UseVisualStyleBackColor = true;
            this.p45.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p44
            // 
            this.p44.Location = new System.Drawing.Point(215, 2);
            this.p44.Margin = new System.Windows.Forms.Padding(2);
            this.p44.Name = "p44";
            this.p44.Size = new System.Drawing.Size(62, 55);
            this.p44.TabIndex = 33;
            this.p44.Text = "button16";
            this.p44.UseVisualStyleBackColor = true;
            this.p44.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s43
            // 
            this.s43.Enabled = false;
            this.s43.Location = new System.Drawing.Point(160, 61);
            this.s43.Margin = new System.Windows.Forms.Padding(2);
            this.s43.Name = "s43";
            this.s43.Size = new System.Drawing.Size(45, 27);
            this.s43.TabIndex = 38;
            this.s43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s43.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s42
            // 
            this.s42.Enabled = false;
            this.s42.Location = new System.Drawing.Point(95, 61);
            this.s42.Margin = new System.Windows.Forms.Padding(2);
            this.s42.Name = "s42";
            this.s42.Size = new System.Drawing.Size(45, 27);
            this.s42.TabIndex = 37;
            this.s42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s42.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.s36);
            this.panel3.Controls.Add(this.p31);
            this.panel3.Controls.Add(this.s35);
            this.panel3.Controls.Add(this.p33);
            this.panel3.Controls.Add(this.p36);
            this.panel3.Controls.Add(this.p32);
            this.panel3.Controls.Add(this.s34);
            this.panel3.Controls.Add(this.s31);
            this.panel3.Controls.Add(this.p35);
            this.panel3.Controls.Add(this.p34);
            this.panel3.Controls.Add(this.s33);
            this.panel3.Controls.Add(this.s32);
            this.panel3.Location = new System.Drawing.Point(9, 243);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(437, 98);
            this.panel3.TabIndex = 1;
            // 
            // s36
            // 
            this.s36.Enabled = false;
            this.s36.Location = new System.Drawing.Point(363, 62);
            this.s36.Margin = new System.Windows.Forms.Padding(2);
            this.s36.Name = "s36";
            this.s36.Size = new System.Drawing.Size(45, 27);
            this.s36.TabIndex = 29;
            this.s36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s36.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p31
            // 
            this.p31.Location = new System.Drawing.Point(11, 3);
            this.p31.Margin = new System.Windows.Forms.Padding(2);
            this.p31.Name = "p31";
            this.p31.Size = new System.Drawing.Size(62, 55);
            this.p31.TabIndex = 18;
            this.p31.Text = "button3";
            this.p31.UseVisualStyleBackColor = true;
            this.p31.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s35
            // 
            this.s35.Enabled = false;
            this.s35.Location = new System.Drawing.Point(288, 62);
            this.s35.Margin = new System.Windows.Forms.Padding(2);
            this.s35.Name = "s35";
            this.s35.Size = new System.Drawing.Size(45, 27);
            this.s35.TabIndex = 28;
            this.s35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s35.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p33
            // 
            this.p33.Location = new System.Drawing.Point(149, 3);
            this.p33.Margin = new System.Windows.Forms.Padding(2);
            this.p33.Name = "p33";
            this.p33.Size = new System.Drawing.Size(62, 55);
            this.p33.TabIndex = 20;
            this.p33.Text = "button6";
            this.p33.UseVisualStyleBackColor = true;
            this.p33.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p36
            // 
            this.p36.Location = new System.Drawing.Point(354, 3);
            this.p36.Margin = new System.Windows.Forms.Padding(2);
            this.p36.Name = "p36";
            this.p36.Size = new System.Drawing.Size(62, 55);
            this.p36.TabIndex = 23;
            this.p36.Text = "button1";
            this.p36.UseVisualStyleBackColor = true;
            this.p36.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p32
            // 
            this.p32.Location = new System.Drawing.Point(83, 3);
            this.p32.Margin = new System.Windows.Forms.Padding(2);
            this.p32.Name = "p32";
            this.p32.Size = new System.Drawing.Size(62, 55);
            this.p32.TabIndex = 19;
            this.p32.Text = "button5";
            this.p32.UseVisualStyleBackColor = true;
            this.p32.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s34
            // 
            this.s34.Enabled = false;
            this.s34.Location = new System.Drawing.Point(223, 62);
            this.s34.Margin = new System.Windows.Forms.Padding(2);
            this.s34.Name = "s34";
            this.s34.Size = new System.Drawing.Size(45, 27);
            this.s34.TabIndex = 27;
            this.s34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s34.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s31
            // 
            this.s31.Enabled = false;
            this.s31.Location = new System.Drawing.Point(19, 62);
            this.s31.Margin = new System.Windows.Forms.Padding(2);
            this.s31.Name = "s31";
            this.s31.Size = new System.Drawing.Size(45, 27);
            this.s31.TabIndex = 24;
            this.s31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s31.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p35
            // 
            this.p35.Location = new System.Drawing.Point(281, 3);
            this.p35.Margin = new System.Windows.Forms.Padding(2);
            this.p35.Name = "p35";
            this.p35.Size = new System.Drawing.Size(62, 55);
            this.p35.TabIndex = 22;
            this.p35.Text = "button2";
            this.p35.UseVisualStyleBackColor = true;
            this.p35.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p34
            // 
            this.p34.Location = new System.Drawing.Point(215, 3);
            this.p34.Margin = new System.Windows.Forms.Padding(2);
            this.p34.Name = "p34";
            this.p34.Size = new System.Drawing.Size(62, 55);
            this.p34.TabIndex = 21;
            this.p34.Text = "button4";
            this.p34.UseVisualStyleBackColor = true;
            this.p34.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s33
            // 
            this.s33.Enabled = false;
            this.s33.Location = new System.Drawing.Point(160, 62);
            this.s33.Margin = new System.Windows.Forms.Padding(2);
            this.s33.Name = "s33";
            this.s33.Size = new System.Drawing.Size(45, 27);
            this.s33.TabIndex = 26;
            this.s33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s33.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s32
            // 
            this.s32.Enabled = false;
            this.s32.Location = new System.Drawing.Point(95, 62);
            this.s32.Margin = new System.Windows.Forms.Padding(2);
            this.s32.Name = "s32";
            this.s32.Size = new System.Drawing.Size(45, 27);
            this.s32.TabIndex = 25;
            this.s32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s32.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.s26);
            this.panel2.Controls.Add(this.s25);
            this.panel2.Controls.Add(this.p26);
            this.panel2.Controls.Add(this.s24);
            this.panel2.Controls.Add(this.p25);
            this.panel2.Controls.Add(this.s23);
            this.panel2.Controls.Add(this.p21);
            this.panel2.Controls.Add(this.s22);
            this.panel2.Controls.Add(this.p24);
            this.panel2.Controls.Add(this.s21);
            this.panel2.Controls.Add(this.p22);
            this.panel2.Controls.Add(this.p23);
            this.panel2.Location = new System.Drawing.Point(9, 129);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(437, 98);
            this.panel2.TabIndex = 1;
            // 
            // s26
            // 
            this.s26.Enabled = false;
            this.s26.Location = new System.Drawing.Point(363, 61);
            this.s26.Margin = new System.Windows.Forms.Padding(2);
            this.s26.Name = "s26";
            this.s26.Size = new System.Drawing.Size(45, 27);
            this.s26.TabIndex = 17;
            this.s26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s26.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s25
            // 
            this.s25.Enabled = false;
            this.s25.Location = new System.Drawing.Point(288, 61);
            this.s25.Margin = new System.Windows.Forms.Padding(2);
            this.s25.Name = "s25";
            this.s25.Size = new System.Drawing.Size(45, 27);
            this.s25.TabIndex = 16;
            this.s25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s25.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p26
            // 
            this.p26.Location = new System.Drawing.Point(354, 2);
            this.p26.Margin = new System.Windows.Forms.Padding(2);
            this.p26.Name = "p26";
            this.p26.Size = new System.Drawing.Size(62, 55);
            this.p26.TabIndex = 11;
            this.p26.Text = "button7";
            this.p26.UseVisualStyleBackColor = true;
            this.p26.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s24
            // 
            this.s24.Enabled = false;
            this.s24.Location = new System.Drawing.Point(223, 61);
            this.s24.Margin = new System.Windows.Forms.Padding(2);
            this.s24.Name = "s24";
            this.s24.Size = new System.Drawing.Size(45, 27);
            this.s24.TabIndex = 15;
            this.s24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s24.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p25
            // 
            this.p25.Location = new System.Drawing.Point(281, 2);
            this.p25.Margin = new System.Windows.Forms.Padding(2);
            this.p25.Name = "p25";
            this.p25.Size = new System.Drawing.Size(62, 55);
            this.p25.TabIndex = 10;
            this.p25.Text = "button8";
            this.p25.UseVisualStyleBackColor = true;
            this.p25.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s23
            // 
            this.s23.Enabled = false;
            this.s23.Location = new System.Drawing.Point(160, 61);
            this.s23.Margin = new System.Windows.Forms.Padding(2);
            this.s23.Name = "s23";
            this.s23.Size = new System.Drawing.Size(45, 27);
            this.s23.TabIndex = 14;
            this.s23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s23.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p21
            // 
            this.p21.Location = new System.Drawing.Point(11, 2);
            this.p21.Margin = new System.Windows.Forms.Padding(2);
            this.p21.Name = "p21";
            this.p21.Size = new System.Drawing.Size(62, 55);
            this.p21.TabIndex = 6;
            this.p21.Text = "button12";
            this.p21.UseVisualStyleBackColor = true;
            this.p21.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s22
            // 
            this.s22.Enabled = false;
            this.s22.Location = new System.Drawing.Point(95, 61);
            this.s22.Margin = new System.Windows.Forms.Padding(2);
            this.s22.Name = "s22";
            this.s22.Size = new System.Drawing.Size(45, 27);
            this.s22.TabIndex = 13;
            this.s22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s22.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p24
            // 
            this.p24.Location = new System.Drawing.Point(215, 2);
            this.p24.Margin = new System.Windows.Forms.Padding(2);
            this.p24.Name = "p24";
            this.p24.Size = new System.Drawing.Size(62, 55);
            this.p24.TabIndex = 9;
            this.p24.Text = "button9";
            this.p24.UseVisualStyleBackColor = true;
            this.p24.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // s21
            // 
            this.s21.Enabled = false;
            this.s21.Location = new System.Drawing.Point(19, 61);
            this.s21.Margin = new System.Windows.Forms.Padding(2);
            this.s21.Name = "s21";
            this.s21.Size = new System.Drawing.Size(45, 27);
            this.s21.TabIndex = 12;
            this.s21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s21.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p22
            // 
            this.p22.Location = new System.Drawing.Point(83, 2);
            this.p22.Margin = new System.Windows.Forms.Padding(2);
            this.p22.Name = "p22";
            this.p22.Size = new System.Drawing.Size(62, 55);
            this.p22.TabIndex = 7;
            this.p22.Text = "button11";
            this.p22.UseVisualStyleBackColor = true;
            this.p22.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p23
            // 
            this.p23.Location = new System.Drawing.Point(149, 2);
            this.p23.Margin = new System.Windows.Forms.Padding(2);
            this.p23.Name = "p23";
            this.p23.Size = new System.Drawing.Size(62, 55);
            this.p23.TabIndex = 8;
            this.p23.Text = "button10";
            this.p23.UseVisualStyleBackColor = true;
            this.p23.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.s16);
            this.panel1.Controls.Add(this.s15);
            this.panel1.Controls.Add(this.s14);
            this.panel1.Controls.Add(this.s13);
            this.panel1.Controls.Add(this.s12);
            this.panel1.Controls.Add(this.s11);
            this.panel1.Controls.Add(this.p16);
            this.panel1.Controls.Add(this.p15);
            this.panel1.Controls.Add(this.p14);
            this.panel1.Controls.Add(this.p13);
            this.panel1.Controls.Add(this.p12);
            this.panel1.Controls.Add(this.p11);
            this.panel1.Location = new System.Drawing.Point(9, 18);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(437, 98);
            this.panel1.TabIndex = 0;
            // 
            // s16
            // 
            this.s16.Enabled = false;
            this.s16.Location = new System.Drawing.Point(363, 61);
            this.s16.Margin = new System.Windows.Forms.Padding(2);
            this.s16.Name = "s16";
            this.s16.Size = new System.Drawing.Size(45, 27);
            this.s16.TabIndex = 11;
            this.s16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s16.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s15
            // 
            this.s15.Enabled = false;
            this.s15.Location = new System.Drawing.Point(288, 61);
            this.s15.Margin = new System.Windows.Forms.Padding(2);
            this.s15.Name = "s15";
            this.s15.Size = new System.Drawing.Size(45, 27);
            this.s15.TabIndex = 10;
            this.s15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s15.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s14
            // 
            this.s14.Enabled = false;
            this.s14.Location = new System.Drawing.Point(223, 61);
            this.s14.Margin = new System.Windows.Forms.Padding(2);
            this.s14.Name = "s14";
            this.s14.Size = new System.Drawing.Size(45, 27);
            this.s14.TabIndex = 9;
            this.s14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s14.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s13
            // 
            this.s13.Enabled = false;
            this.s13.Location = new System.Drawing.Point(160, 61);
            this.s13.Margin = new System.Windows.Forms.Padding(2);
            this.s13.Name = "s13";
            this.s13.Size = new System.Drawing.Size(45, 27);
            this.s13.TabIndex = 8;
            this.s13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s13.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s12
            // 
            this.s12.Enabled = false;
            this.s12.Location = new System.Drawing.Point(95, 61);
            this.s12.Margin = new System.Windows.Forms.Padding(2);
            this.s12.Name = "s12";
            this.s12.Size = new System.Drawing.Size(45, 27);
            this.s12.TabIndex = 7;
            this.s12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // s11
            // 
            this.s11.Enabled = false;
            this.s11.Location = new System.Drawing.Point(19, 61);
            this.s11.Margin = new System.Windows.Forms.Padding(2);
            this.s11.Name = "s11";
            this.s11.Size = new System.Drawing.Size(45, 27);
            this.s11.TabIndex = 6;
            this.s11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stanjePozicijaVisual_MouseDown);
            // 
            // p16
            // 
            this.p16.Location = new System.Drawing.Point(354, 2);
            this.p16.Margin = new System.Windows.Forms.Padding(2);
            this.p16.Name = "p16";
            this.p16.Size = new System.Drawing.Size(62, 55);
            this.p16.TabIndex = 5;
            this.p16.Text = "Empty";
            this.p16.UseVisualStyleBackColor = true;
            this.p16.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p15
            // 
            this.p15.Location = new System.Drawing.Point(281, 2);
            this.p15.Margin = new System.Windows.Forms.Padding(2);
            this.p15.Name = "p15";
            this.p15.Size = new System.Drawing.Size(62, 55);
            this.p15.TabIndex = 4;
            this.p15.Text = "Empty";
            this.p15.UseVisualStyleBackColor = true;
            this.p15.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p14
            // 
            this.p14.Location = new System.Drawing.Point(215, 2);
            this.p14.Margin = new System.Windows.Forms.Padding(2);
            this.p14.Name = "p14";
            this.p14.Size = new System.Drawing.Size(62, 55);
            this.p14.TabIndex = 3;
            this.p14.Text = "Empty";
            this.p14.UseVisualStyleBackColor = true;
            this.p14.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p13
            // 
            this.p13.Location = new System.Drawing.Point(149, 2);
            this.p13.Margin = new System.Windows.Forms.Padding(2);
            this.p13.Name = "p13";
            this.p13.Size = new System.Drawing.Size(62, 55);
            this.p13.TabIndex = 2;
            this.p13.Text = "Empty";
            this.p13.UseVisualStyleBackColor = true;
            this.p13.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p12
            // 
            this.p12.Location = new System.Drawing.Point(83, 2);
            this.p12.Margin = new System.Windows.Forms.Padding(2);
            this.p12.Name = "p12";
            this.p12.Size = new System.Drawing.Size(62, 55);
            this.p12.TabIndex = 1;
            this.p12.Text = "Empty";
            this.p12.UseVisualStyleBackColor = true;
            this.p12.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // p11
            // 
            this.p11.Location = new System.Drawing.Point(11, 2);
            this.p11.Margin = new System.Windows.Forms.Padding(2);
            this.p11.Name = "p11";
            this.p11.Size = new System.Drawing.Size(62, 55);
            this.p11.TabIndex = 0;
            this.p11.Text = "Empty";
            this.p11.UseVisualStyleBackColor = true;
            this.p11.Click += new System.EventHandler(this.pozicijaArtikal_Click);
            // 
            // panelOdrzavanje
            // 
            this.panelOdrzavanje.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOdrzavanje.Controls.Add(this.ispraznikasu);
            this.panelOdrzavanje.Controls.Add(this.ubaciNovcanicu);
            this.panelOdrzavanje.Controls.Add(this.label1);
            this.panelOdrzavanje.Controls.Add(this.ubacenaNovcanica);
            this.panelOdrzavanje.Controls.Add(this.napuniAutomat);
            this.panelOdrzavanje.Controls.Add(this.ubaciArtikal);
            this.panelOdrzavanje.Controls.Add(this.procenatPopusta);
            this.panelOdrzavanje.Controls.Add(this.label8);
            this.panelOdrzavanje.Controls.Add(this.popustNaDan);
            this.panelOdrzavanje.Controls.Add(this.label7);
            this.panelOdrzavanje.Controls.Add(this.rok);
            this.panelOdrzavanje.Controls.Add(this.label6);
            this.panelOdrzavanje.Controls.Add(this.cena);
            this.panelOdrzavanje.Controls.Add(this.label5);
            this.panelOdrzavanje.Controls.Add(this.naziv);
            this.panelOdrzavanje.Controls.Add(this.label4);
            this.panelOdrzavanje.Controls.Add(this.label3);
            this.panelOdrzavanje.Controls.Add(this.kolicina);
            this.panelOdrzavanje.Controls.Add(this.infoPozicije);
            this.panelOdrzavanje.Controls.Add(this.kljuc);
            this.panelOdrzavanje.Location = new System.Drawing.Point(498, 267);
            this.panelOdrzavanje.Margin = new System.Windows.Forms.Padding(2);
            this.panelOdrzavanje.Name = "panelOdrzavanje";
            this.panelOdrzavanje.Size = new System.Drawing.Size(293, 458);
            this.panelOdrzavanje.TabIndex = 13;
            // 
            // ispraznikasu
            // 
            this.ispraznikasu.Enabled = false;
            this.ispraznikasu.Location = new System.Drawing.Point(155, 403);
            this.ispraznikasu.Name = "ispraznikasu";
            this.ispraznikasu.Size = new System.Drawing.Size(127, 26);
            this.ispraznikasu.TabIndex = 19;
            this.ispraznikasu.Text = "Isprazni kasu";
            this.ispraznikasu.UseVisualStyleBackColor = true;
            this.ispraznikasu.Click += new System.EventHandler(this.ispraznikasu_Click);
            // 
            // ubaciNovcanicu
            // 
            this.ubaciNovcanicu.Enabled = false;
            this.ubaciNovcanicu.Location = new System.Drawing.Point(98, 401);
            this.ubaciNovcanicu.Name = "ubaciNovcanicu";
            this.ubaciNovcanicu.Size = new System.Drawing.Size(41, 29);
            this.ubaciNovcanicu.TabIndex = 18;
            this.ubaciNovcanicu.Text = "+";
            this.ubaciNovcanicu.UseVisualStyleBackColor = true;
            this.ubaciNovcanicu.Click += new System.EventHandler(this.ubaciNovcanicu_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 374);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Ubacite novac u kasu";
            // 
            // ubacenaNovcanica
            // 
            this.ubacenaNovcanica.Enabled = false;
            this.ubacenaNovcanica.Location = new System.Drawing.Point(24, 401);
            this.ubacenaNovcanica.Name = "ubacenaNovcanica";
            this.ubacenaNovcanica.Size = new System.Drawing.Size(68, 27);
            this.ubacenaNovcanica.TabIndex = 16;
            // 
            // napuniAutomat
            // 
            this.napuniAutomat.Enabled = false;
            this.napuniAutomat.Location = new System.Drawing.Point(13, 335);
            this.napuniAutomat.Margin = new System.Windows.Forms.Padding(2);
            this.napuniAutomat.Name = "napuniAutomat";
            this.napuniAutomat.Size = new System.Drawing.Size(272, 27);
            this.napuniAutomat.TabIndex = 15;
            this.napuniAutomat.Text = "Napuni automat";
            this.napuniAutomat.UseVisualStyleBackColor = true;
            this.napuniAutomat.Click += new System.EventHandler(this.napuniAutomat_Click);
            // 
            // ubaciArtikal
            // 
            this.ubaciArtikal.Enabled = false;
            this.ubaciArtikal.Location = new System.Drawing.Point(11, 297);
            this.ubaciArtikal.Margin = new System.Windows.Forms.Padding(2);
            this.ubaciArtikal.Name = "ubaciArtikal";
            this.ubaciArtikal.Size = new System.Drawing.Size(274, 27);
            this.ubaciArtikal.TabIndex = 14;
            this.ubaciArtikal.Text = "Ubaci artikal";
            this.ubaciArtikal.UseVisualStyleBackColor = true;
            this.ubaciArtikal.Click += new System.EventHandler(this.ubaciArtikal_Click);
            // 
            // procenatPopusta
            // 
            this.procenatPopusta.Enabled = false;
            this.procenatPopusta.Location = new System.Drawing.Point(221, 245);
            this.procenatPopusta.Margin = new System.Windows.Forms.Padding(2);
            this.procenatPopusta.Name = "procenatPopusta";
            this.procenatPopusta.Size = new System.Drawing.Size(65, 27);
            this.procenatPopusta.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 249);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 20);
            this.label8.TabIndex = 12;
            this.label8.Text = "% popusta";
            // 
            // popustNaDan
            // 
            this.popustNaDan.Enabled = false;
            this.popustNaDan.Location = new System.Drawing.Point(168, 212);
            this.popustNaDan.Margin = new System.Windows.Forms.Padding(2);
            this.popustNaDan.Name = "popustNaDan";
            this.popustNaDan.Size = new System.Drawing.Size(118, 27);
            this.popustNaDan.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 212);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 20);
            this.label7.TabIndex = 10;
            this.label7.Text = "Popust na dan";
            // 
            // rok
            // 
            this.rok.Enabled = false;
            this.rok.Location = new System.Drawing.Point(168, 177);
            this.rok.Margin = new System.Windows.Forms.Padding(2);
            this.rok.Name = "rok";
            this.rok.Size = new System.Drawing.Size(118, 27);
            this.rok.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 180);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "Rok";
            // 
            // cena
            // 
            this.cena.Enabled = false;
            this.cena.Location = new System.Drawing.Point(221, 141);
            this.cena.Margin = new System.Windows.Forms.Padding(2);
            this.cena.Name = "cena";
            this.cena.Size = new System.Drawing.Size(65, 27);
            this.cena.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 145);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Cena";
            // 
            // naziv
            // 
            this.naziv.Enabled = false;
            this.naziv.Location = new System.Drawing.Point(168, 107);
            this.naziv.Margin = new System.Windows.Forms.Padding(2);
            this.naziv.Name = "naziv";
            this.naziv.Size = new System.Drawing.Size(118, 27);
            this.naziv.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 111);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Naziv";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 77);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Kolicina";
            // 
            // kolicina
            // 
            this.kolicina.Enabled = false;
            this.kolicina.Location = new System.Drawing.Point(221, 73);
            this.kolicina.Margin = new System.Windows.Forms.Padding(2);
            this.kolicina.Name = "kolicina";
            this.kolicina.Size = new System.Drawing.Size(65, 27);
            this.kolicina.TabIndex = 2;
            // 
            // infoPozicije
            // 
            this.infoPozicije.Location = new System.Drawing.Point(11, 43);
            this.infoPozicije.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.infoPozicije.Name = "infoPozicije";
            this.infoPozicije.Size = new System.Drawing.Size(274, 23);
            this.infoPozicije.TabIndex = 1;
            this.infoPozicije.Text = "info";
            this.infoPozicije.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // kljuc
            // 
            this.kljuc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.kljuc.Location = new System.Drawing.Point(202, 2);
            this.kljuc.Margin = new System.Windows.Forms.Padding(2);
            this.kljuc.Name = "kljuc";
            this.kljuc.Size = new System.Drawing.Size(87, 27);
            this.kljuc.TabIndex = 0;
            this.kljuc.Text = "otkljucaj";
            this.kljuc.UseVisualStyleBackColor = true;
            this.kljuc.Click += new System.EventHandler(this.kljuc_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(705, 136);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 20);
            this.label9.TabIndex = 14;
            this.label9.Text = "Kredit";
            // 
            // kredit
            // 
            this.kredit.Location = new System.Drawing.Point(705, 169);
            this.kredit.Margin = new System.Windows.Forms.Padding(2);
            this.kredit.Name = "kredit";
            this.kredit.Size = new System.Drawing.Size(83, 27);
            this.kredit.TabIndex = 15;
            // 
            // kusur
            // 
            this.kusur.Location = new System.Drawing.Point(27, 765);
            this.kusur.Margin = new System.Windows.Forms.Padding(2);
            this.kusur.Name = "kusur";
            this.kusur.Size = new System.Drawing.Size(153, 178);
            this.kusur.TabIndex = 16;
            this.kusur.Text = "";
            // 
            // isporuceno
            // 
            this.isporuceno.Location = new System.Drawing.Point(235, 765);
            this.isporuceno.Margin = new System.Windows.Forms.Padding(2);
            this.isporuceno.Name = "isporuceno";
            this.isporuceno.Size = new System.Drawing.Size(549, 185);
            this.isporuceno.TabIndex = 17;
            this.isporuceno.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(28, 735);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 20);
            this.label10.TabIndex = 18;
            this.label10.Text = "KUSUR";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(235, 735);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 20);
            this.label11.TabIndex = 19;
            this.label11.Text = "PREUZIMANJE";
            // 
            // vratiKusur
            // 
            this.vratiKusur.BackColor = System.Drawing.Color.ForestGreen;
            this.vratiKusur.Location = new System.Drawing.Point(498, 214);
            this.vratiKusur.Margin = new System.Windows.Forms.Padding(2);
            this.vratiKusur.Name = "vratiKusur";
            this.vratiKusur.Size = new System.Drawing.Size(283, 39);
            this.vratiKusur.TabIndex = 20;
            this.vratiKusur.Text = "KUSUR";
            this.vratiKusur.UseVisualStyleBackColor = false;
            this.vratiKusur.Click += new System.EventHandler(this.vratiKusur_Click);
            // 
            // novcanica2
            // 
            this.novcanica2.Location = new System.Drawing.Point(596, 44);
            this.novcanica2.Margin = new System.Windows.Forms.Padding(2);
            this.novcanica2.Name = "novcanica2";
            this.novcanica2.Size = new System.Drawing.Size(87, 27);
            this.novcanica2.TabIndex = 21;
            this.novcanica2.Text = "2";
            this.novcanica2.UseVisualStyleBackColor = true;
            this.novcanica2.Click += new System.EventHandler(this.novcanica_Click);
            // 
            // novcanica1
            // 
            this.novcanica1.Location = new System.Drawing.Point(493, 42);
            this.novcanica1.Margin = new System.Windows.Forms.Padding(2);
            this.novcanica1.Name = "novcanica1";
            this.novcanica1.Size = new System.Drawing.Size(87, 27);
            this.novcanica1.TabIndex = 22;
            this.novcanica1.Text = "1";
            this.novcanica1.UseVisualStyleBackColor = true;
            this.novcanica1.Click += new System.EventHandler(this.novcanica_Click);
            // 
            // stanjeKase
            // 
            this.stanjeKase.Location = new System.Drawing.Point(705, 85);
            this.stanjeKase.Margin = new System.Windows.Forms.Padding(2);
            this.stanjeKase.Name = "stanjeKase";
            this.stanjeKase.Size = new System.Drawing.Size(83, 27);
            this.stanjeKase.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(704, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 20);
            this.label2.TabIndex = 24;
            this.label2.Text = "Stanje";
            // 
            // preuzmiKusur
            // 
            this.preuzmiKusur.Location = new System.Drawing.Point(89, 732);
            this.preuzmiKusur.Name = "preuzmiKusur";
            this.preuzmiKusur.Size = new System.Drawing.Size(91, 26);
            this.preuzmiKusur.TabIndex = 25;
            this.preuzmiKusur.Text = "preuzmi";
            this.preuzmiKusur.UseVisualStyleBackColor = true;
            this.preuzmiKusur.Click += new System.EventHandler(this.preuzmiKusur_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 976);
            this.Controls.Add(this.preuzmiKusur);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.stanjeKase);
            this.Controls.Add(this.novcanica1);
            this.Controls.Add(this.novcanica2);
            this.Controls.Add(this.vratiKusur);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.isporuceno);
            this.Controls.Add(this.kusur);
            this.Controls.Add(this.kredit);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panelOdrzavanje);
            this.Controls.Add(this.panelMagacin);
            this.Controls.Add(this.novcanica200);
            this.Controls.Add(this.novcanica100);
            this.Controls.Add(this.novcanica50);
            this.Controls.Add(this.novcanica20);
            this.Controls.Add(this.novcanica10);
            this.Controls.Add(this.novcanica5);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximumSize = new System.Drawing.Size(821, 1349);
            this.MinimumSize = new System.Drawing.Size(821, 708);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Automat";
            this.panelMagacin.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelOdrzavanje.ResumeLayout(false);
            this.panelOdrzavanje.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button novcanica5;
        private Button novcanica10;
        private Button novcanica20;
        private Button novcanica50;
        private Button novcanica100;
        private Button novcanica200;
        private Panel panelMagacin;
        private Panel panelOdrzavanje;
        private Panel panel6;
        private Panel panel5;
        private Panel panel4;
        private Panel panel3;
        private Panel panel2;
        private Panel panel1;
        private TextBox s26;
        private TextBox s25;
        private Button p26;
        private TextBox s24;
        private Button p25;
        private TextBox s23;
        private Button p21;
        private TextBox s22;
        private Button p24;
        private TextBox s21;
        private Button p22;
        private Button p23;
        private TextBox s16;
        private TextBox s15;
        private TextBox s14;
        private TextBox s13;
        private TextBox s12;
        private TextBox s11;
        private Button p16;
        private Button p15;
        private Button p14;
        private Button p13;
        private Button p12;
        private Button p11;
        private Button kljuc;
        private Label infoPozicije;
        private Label label3;
        private TextBox kolicina;
        private TextBox naziv;
        private Label label4;
        private TextBox rok;
        private Label label6;
        private TextBox cena;
        private Label label5;
        private TextBox procenatPopusta;
        private Label label8;
        private TextBox popustNaDan;
        private Label label7;
        private Button ubaciArtikal;
        private TextBox s66;
        private Button p61;
        private TextBox s65;
        private Button p63;
        private Button p66;
        private Button p62;
        private TextBox s64;
        private TextBox s61;
        private Button p65;
        private Button p64;
        private TextBox s63;
        private TextBox s62;
        private TextBox s56;
        private Button p51;
        private TextBox s55;
        private Button p53;
        private Button p56;
        private Button p52;
        private TextBox s54;
        private TextBox s51;
        private Button p55;
        private Button p54;
        private TextBox s53;
        private TextBox s52;
        private TextBox s46;
        private Button p41;
        private TextBox s45;
        private Button p43;
        private Button p46;
        private Button p42;
        private TextBox s44;
        private TextBox s41;
        private Button p45;
        private Button p44;
        private TextBox s43;
        private TextBox s42;
        private TextBox s36;
        private Button p31;
        private TextBox s35;
        private Button p33;
        private Button p36;
        private Button p32;
        private TextBox s34;
        private TextBox s31;
        private Button p35;
        private Button p34;
        private TextBox s33;
        private TextBox s32;
        private Button napuniAutomat;
        private Label label9;
        private TextBox kredit;
        private RichTextBox kusur;
        private RichTextBox isporuceno;
        private Label label10;
        private Label label11;
        private Button vratiKusur;
        private Button novcanica2;
        private Button novcanica1;
        private Button ubaciNovcanicu;
        private Label label1;
        private TextBox ubacenaNovcanica;
        private TextBox stanjeKase;
        private Label label2;
        private Button preuzmiKusur;
        private Button ispraznikasu;
    }
}